class ReleaseEntry {
  const ReleaseEntry({
    required this.version,
    required this.buildNumber,
    required this.title,
    required this.summary,
    required this.changes,
  });

  final String version;
  final int buildNumber;
  final String title;
  final String summary;
  final List<String> changes;

  String get fullVersion => '$version+$buildNumber';
}

class AppVersion {
  static const String currentVersion = '2.1.47';
  static const int currentBuildNumber = 47;
  static const String fullVersion = '$currentVersion+$currentBuildNumber';

  static const List<ReleaseEntry> history = <ReleaseEntry>[
    ReleaseEntry(
      version: '2.1.47',
      buildNumber: 47,
      title: 'Исправлен вызов withValues на Color для совместимости с Flutter 3.24',
      summary: 'В виджете MacOsWindowTitleBar заменён вызов .withValues(alpha: 0.78) на .withOpacity(0.78), поддерживаемый в Flutter 3.24.5.',
      changes: [
        'Заменён .withValues(alpha: 0.78) на .withOpacity(0.78) в lib/widgets/macos_window_title_bar.dart',
        'Обновлена версия до 2.1.47+47 в AppVersion, pubspec.yaml, CHANGELOG.md и HANDOFF.yaml',
      ],
    ),
    ReleaseEntry(
      version: '2.1.46',
      buildNumber: 46,
      title: 'Исправлен вызов методов из static applyDownloadedBuild в BuildBundleService',
      summary: 'Вспомогательные методы _clearDirectorySafe, _copyDirectoryContentsSafe, _pruneHistory и _launchNewestExeIfAny возвращены в класс BuildBundleService с модификатором static.',
      changes: [
        'Возвращены _clearDirectorySafe, _copyDirectoryContentsSafe, _pruneHistory и _launchNewestExeIfAny в BuildBundleService как static-методы',
        'Устранена ошибка instance_member_access_from_static при вызове из applyDownloadedBuild',
        'Обновлена версия до 2.1.46+46 в AppVersion, pubspec.yaml, CHANGELOG.md и HANDOFF.yaml',
      ],
    ),
    ReleaseEntry(
      version: '2.1.45',
      buildNumber: 45,
      title: 'Панель окна в стиле macOS с поведением кнопок Windows',
      summary: 'Добавлена верхняя панель окна в стиле macOS («светофор») с сохранением поведения кнопок и границ изменения размера окна Windows через Win32 и MethodChannel.',
      changes: [
        'Добавлен виджет MacOsWindowTitleBar с кнопками закрытия, сворачивания и разворачивания/восстановления окна и перетаскиванием заголовка',
        'Настроен Win32-обработчик окна в windows/runner/flutter_window.cpp с сохранением рамки изменения размера и команд окна Windows',
        'Обновлена версия до 2.1.45+45 в AppVersion, pubspec.yaml, CHANGELOG.md и HANDOFF.yaml',
      ],
    ),
    ReleaseEntry(
      version: '2.1.44',
      buildNumber: 44,
      title: 'Исправлены ошибки и замечания flutter analyze в релизе 2.1.43',
      summary: 'Исправлены модификаторы методов расширения в build_bundle_service.dart, объявления полей и структура Column в build_capture_tab.dart, а также удалён неиспользуемый импорт в home_screen.dart.',
      changes: [
        'Оформлены вспомогательные методы BuildBundleService в расширение без лишнего static и удалён неиспользуемый _clearDirectory',
        'Добавлены поля _buildAutoLaunchExe и _buildHistoryKeepCount и исправлена структура Column для журнала распаковки в build_capture_tab.dart',
        'Удалён неиспользуемый импорт agent_template_item.dart в home_screen.dart',
      ],
    ),
    ReleaseEntry(
      version: '2.1.43',
      buildNumber: 43,
      title: 'Исправлена ручная проверка и скачивание сборок с GitHub',
      summary: 'При ручном нажатии «Проверить и скачать с GitHub» добавлен forceRecheck, перебор последних успешных run и подробное логирование причин, если сборка не найдена или не задан URL/токен.',
      changes: [
        'Добавлен флаг forceRecheck при ручной проверке сборок с GitHub',
        'Добавлен перебор последних успешных workflow runs и проверка просроченных/пустых артефактов',
        'Добавлены понятные сообщения и записи в журнал при пустом URL, отсутствии токена или уже обработанной сборке',
      ],
    ),
    ReleaseEntry(
      version: '2.1.42',
      buildNumber: 42,
      title: 'Полноценное создание и редактирование новых шаблонов в библиотеке',
      summary: 'Вынесен диалог библиотеки шаблонов в lib/widgets/template_manager_dialog.dart, исправлена работа с черновиком нового шаблона, фокусом и сохранением.',
      changes: [
        'Вынесен TemplateManagerDialog в lib/widgets/template_manager_dialog.dart с явным управлением состоянием черновика нового шаблона',
        'Исправлено выделение/редактирование названия и текста нового шаблона с сохранением через provider.saveTemplate',
        'Обновлена карта модулей MAP.md и версия сборки до 2.1.42+42',
      ],
    ),
    ReleaseEntry(
      version: '2.1.41',
      buildNumber: 41,
      title: 'Журнал распаковки в стиле авто-деплоя, ротация _history и автозапуск .exe',
      summary: 'Журнал распаковки оформлен в едином тёмном стиле с журналом авто-деплоя, добавлены ротация _history, бережная обработка занятых файлов и опциональный запуск .exe.',
      changes: [
        'Добавлен журнал распаковки в стиле консоли авто-деплоя (0xFF141A26, Consolas, кнопка «Очистить») и статус последней проверки GitHub',
        'Добавлена ротация копий в _history (buildHistoryKeepCount) и бережная обработка занятых файлов при распаковке',
        'Добавлен опциональный автозапуск найденного .exe после обновления папки current (buildAutoLaunchExe)',
      ],
    ),
    ReleaseEntry(
      version: '2.1.40',
      buildNumber: 40,
      title: 'Исправлено редактирование нового шаблона и ошибки анализатора из 2.1.39',
      summary: 'Добавлены FocusNode и явное управление фокусом/readOnly в редакторе шаблонов, исправлены вызовы диалогов и удалены неиспользуемые импорты и функции.',
      changes: [
        'Добавлены _nameFocusNode, _contentFocusNode, readOnly: false и автофокус при создании шаблона в _TemplateManagerDialog',
        'Исправлены вызовы showCreateProjectDialog и showAboutBackupDialog в home_screen.dart',
        'Удалены неиспользуемые импорты и функции в home_screen.dart и about_backup_dialog.dart',
      ],
    ),
  ];
}
