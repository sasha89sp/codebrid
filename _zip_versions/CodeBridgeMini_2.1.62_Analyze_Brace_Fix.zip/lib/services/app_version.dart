class ReleaseEntry {
  const ReleaseEntry({
    required this.version,
    required this.buildNumber,
    required this.title,
    required this.summary,
    required this.changes,
  });

  final String version;
  final int buildNumber;
  final String title;
  final String summary;
  final List<String> changes;

  String get fullVersion => '$version+$buildNumber';
}

class AppVersion {
  static const String currentVersion = '2.1.62';
  static const int currentBuildNumber = 62;
  static const String fullVersion = '$currentVersion+$currentBuildNumber';

  static const List<ReleaseEntry> history = <ReleaseEntry>[
    ReleaseEntry(
      version: '2.1.62',
      buildNumber: 62,
      title: 'Убраны лишние фигурные скобки в строковой интерполяции github_build_fetcher_service.dart',
      summary: 'Исправлено замечание анализатора unnecessary_brace_in_string_interps на строке 43 в lib/services/github_build_fetcher_service.dart.',
      changes: [
        'Заменено [${branch}] на [$branch] в lib/services/github_build_fetcher_service.dart',
        'Обновлена версия до 2.1.62+62 в AppVersion, pubspec.yaml, CHANGELOG.md и HANDOFF.yaml',
      ],
    ),
    ReleaseEntry(
      version: '2.1.61',
      buildNumber: 61,
      title: 'Оповещение об упавшей сборке GitHub в статусе, журнале и баннере',
      summary: 'При проверке сборок с GitHub программа отслеживает статус последнего завершённого workflow run и при ошибке сборки выводит красный баннер, подсвечивает строку статуса и записывает ошибку в журнал распаковки.',
      changes: [
        'В GitHubBuildFetcherService добавлено определение упавших workflow runs (failure, cancelled, timed_out и др.) с номером run, веткой и коммитом',
        'Добавлены красный баннер с кнопкой скрытия, подсветка статуса «Последняя проверка GitHub» и запись [ОШИБКА СБОРКИ GITHUB] в журнал распаковки',
        'Обновлена версия до 2.1.61+61 в AppVersion, pubspec.yaml, CHANGELOG.md и HANDOFF.yaml',
      ],
    ),
    ReleaseEntry(
      version: '2.1.60',
      buildNumber: 60,
      title: 'Добавлено поле currentProjectNotes в ProjectProvider для вкладки «Заметки»',
      summary: 'Исправлена ошибка анализатора undefined_identifier/undefined_getter: в ProjectProvider объявлено поле currentProjectNotes для хранения заметок и папок активного проекта.',
      changes: [
        'Добавлено поле ProjectNotesStore currentProjectNotes = const ProjectNotesStore() в lib/providers/project_provider.dart',
        'Обновлена версия до 2.1.60+60 в AppVersion, pubspec.yaml, CHANGELOG.md и HANDOFF.yaml',
      ],
    ),
    ReleaseEntry(
      version: '2.1.59',
      buildNumber: 59,
      title: 'Вкладка «Заметки» с папками и заметками для багов с привязкой к проекту',
      summary: 'Добавлена новая вкладка «Заметки» для каждого проекта с созданием папок, заметок, быстрым шаблоном записи бага и сохранением в data/projects/<id>/notes.json.',
      changes: [
        'Добавлена модель ProjectNotesStore / ProjectNoteFolder / ProjectNoteItem и сохранение заметок строго внутри каталога выбранного проекта (notes.json)',
        'Добавлена вкладка «Заметки» (ProjectNotesTab) с папками, поиском, быстрой кнопкой «Записать баг» и встроенным редактором заметок',
        'Обновлена версия до 2.1.59+59 в AppVersion, pubspec.yaml, CHANGELOG.md и HANDOFF.yaml',
      ],
    ),
    ReleaseEntry(
      version: '2.1.58',
      buildNumber: 58,
      title: 'Сохранение развёрнутого состояния окна после сворачивания и разворачивания',
      summary: 'При сворачивании окна, развёрнутого на весь экран, запоминается его состояние максимизации/полного экрана, и при возврате из панели задач или трея окно снова открывается на весь экран.',
      changes: [
        'В MacOsWindowTitleBar добавлено запоминание состояния максимизации/полного экрана перед сворачиванием и автоматическое восстановление при возврате окна',
        'В WindowSizeListener и AppTrayService защищено сохранение флагов windowIsMaximized/windowIsFullScreen при сворачивании окна',
        'Обновлена версия до 2.1.58+58 в AppVersion, pubspec.yaml, CHANGELOG.md и HANDOFF.yaml',
      ],
    ),
    ReleaseEntry(
      version: '2.1.57',
      buildNumber: 57,
      title: 'Удалён неиспользуемый импорт dart:convert в build_bundle_service.dart',
      summary: 'Устранено предупреждение unused_import (dart:convert) в lib/services/build_bundle_service.dart для прохождения flutter analyze.',
      changes: [
        'Удалён неиспользуемый импорт dart:convert в lib/services/build_bundle_service.dart',
        'Обновлена версия до 2.1.57+57 в AppVersion, pubspec.yaml, CHANGELOG.md и HANDOFF.yaml',
      ],
    ),
    ReleaseEntry(
      version: '2.1.56',
      buildNumber: 56,
      title: 'Отображение скачанной/распакованной версии и иконка приложения в панели задач Windows',
      summary: 'При скачивании и распаковке сборки определяется и отображается её версия в статусе и журнале, а в исполняемый файл и окно Windows встроена иконка приложения для панели задач.',
      changes: [
        'Добавлено определение версии скачанной и распакованной сборки и её вывод в сводке «Последняя проверка GitHub» и журнале распаковки',
        'Встроена иконка IDI_APP_ICON в Runner.rc, win32_window.cpp (WM_SETICON) и windowManager.setIcon для отображения значка в панели задач Windows',
        'Обновлена версия до 2.1.56+56 в AppVersion, pubspec.yaml, CHANGELOG.md и HANDOFF.yaml',
      ],
    ),
    ReleaseEntry(
      version: '2.1.55',
      buildNumber: 55,
      title: 'Исправлена инициализация и copyWith для logRetentionDays в AppSettings',
      summary: 'В класс AppSettings добавлены инициализация по умолчанию (30 дней), именованный параметр copyWith и сериализация JSON для поля logRetentionDays.',
      changes: [
        'Добавлен параметр this.logRetentionDays = 30 в конструктор AppSettings',
        'Добавлен именованный параметр int? logRetentionDays в AppSettings.copyWith и сериализация toJson/fromJson',
        'Обновлена версия до 2.1.55+55 в AppVersion, pubspec.yaml, CHANGELOG.md и HANDOFF.yaml',
      ],
    ),
  ];
}
